/* =====================================================================
   Stellenbosch Work Centre — front-end logic
   NOTE: This is a client-side PROTOTYPE. It simulates the database with
   localStorage so the workflows in the spec (login, roles,
   shop with make-to-order times, courier delivery, staff/admin management) all work in the browser. For production
   you still need a real backend (e.g. Node/.NET) talking to SQL Server —
   the functions below (saveUser, saveRegistration, saveOrder, etc.) are
   exactly where you'd swap in fetch() calls to your API.
   ===================================================================== */
(function () {
  "use strict";

  /* ---------------- Storage helpers (stand-in for the database) ---------------- */
  const DB = {
    get(key, fallback) {
      try { const v = JSON.parse(localStorage.getItem(key)); return v === null ? fallback : v; }
      catch (e) { return fallback; }
    },
    set(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
  };

  const KEYS = {
    users: "swc_users",
    currentUser: "swc_currentUser",
    registrations: "swc_registrations",
    orders: "swc_orders",
    cart: "swc_cart",
    feedback: "swc_feedback"
  };

  // Built-in demo Staff / Administrator accounts (role assigned by the system,
  // not chosen by the user). There is no public sign-up: accounts are issued by the Work Centre.
  // Replace these placeholders with the Work Centre's real business banking details.
  // Never collect online banking passwords, PINs or OTPs in this front-end prototype.
  const BANK_DETAILS = {
    bankName: "YOUR BANK NAME",
    accountName: "Stellenbosch Work Centre",
    accountNumber: "YOUR ACCOUNT NUMBER",
    branchCode: "YOUR BRANCH CODE"
  };

  const SYSTEM_ACCOUNTS = [
    { email: "customer@example.com", password: "customer123", role: "registered", name: "Demo Customer" },
    { email: "staff@stellenboschwork.org", password: "staff123", role: "staff", name: "Staff Member" },
    { email: "admin@stellenboschwork.org", password: "admin123", role: "admin", name: "Administrator" }
  ];

  /* ---------------- Shared admin sidebar (kept identical across every admin page) ---------------- */
  const ADMIN_NAV_HTML = `
    <h3>Admin Dashboard<small>Stellenbosch Work Centre</small></h3>
    <a href="#admin" data-route="admin">◉ Overview</a>
    <a href="#donations-admin" data-route="donations-admin">▤ Donations</a>
    <a href="#programs" data-route="programs">▦ Programs</a>
    <a href="#products-admin" data-route="products-admin">▣ Shop Products</a>
    <hr>
    <a href="#home" data-route="home">⇥ Back to Website</a>
    <a href="#ai-support" data-route="ai-support">✦ AI Support</a>`;
  document.querySelectorAll("[data-admin-nav]").forEach((aside) => { aside.innerHTML = ADMIN_NAV_HTML; });

  /* ---------------- Router ---------------- */
  const pages = Array.from(document.querySelectorAll(".page"));
  const navLinks = Array.from(document.querySelectorAll("[data-route]"));

  // Pages that require a logged-in user, and which role(s) may see them
  const ROUTE_GUARDS = {
    account: ["registered", "staff", "admin"],
    cart: ["registered", "staff", "admin"],
    staff: ["staff", "admin"],
    admin: ["admin"],
    "donations-admin": ["admin"],
    programs: ["admin"],
    "products-admin": ["admin"]
  };

  function currentUser() { return DB.get(KEYS.currentUser, null); }

  function route() {
    let name = (location.hash || "#home").slice(1);
    const guard = ROUTE_GUARDS[name];
    if (guard) {
      const user = currentUser();
      if (!user || !guard.includes(user.role)) {
        // Not allowed here: bounce to login (or home if already logged in with wrong role)
        location.hash = user ? "#home" : "#login";
        return;
      }
    }
    if (!pages.some((p) => p.dataset.page === name)) name = "home";

    pages.forEach((p) => p.classList.toggle("is-active", p.dataset.page === name));
    navLinks.forEach((a) => a.classList.toggle("active", a.dataset.route === name));

    if (name === "account") renderAccount();
    if (name === "cart") renderCart();
    if (name === "staff") renderStaff();

    document.getElementById("app").focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
    closeMobileMenu();
  }
  window.addEventListener("hashchange", route);

  /* ---------------- Mobile menu ---------------- */
  const menuToggle = document.getElementById("menuToggle");
  const mainNav = document.getElementById("mainNav");
  function closeMobileMenu() {
    mainNav.classList.remove("open");
    if (menuToggle) menuToggle.setAttribute("aria-expanded", "false");
  }
  if (menuToggle) {
    menuToggle.addEventListener("click", () => {
      const open = mainNav.classList.toggle("open");
      menuToggle.setAttribute("aria-expanded", String(open));
    });
  }

  /* ---------------- Auth / role-based UI ---------------- */
  function renderAuthUI() {
    const user = currentUser();
    const $ = (id) => document.getElementById(id);
    // Toggle the "role-only" class itself rather than inline display: the
    // stylesheet's .role-only{display:none} was beating an empty inline
    // style, which is why Logout/Account/Staff/Admin never reappeared.
    const show = (el, on) => { if (el) el.classList.toggle("role-only", !on); };

    show($("navLogin"), !user);
    show($("navAccount"), !!user);
    show($("navLogout"), !!user);
    show($("navStaff"), !!user && (user.role === "staff" || user.role === "admin"));
    show($("navAdmin"), !!user && user.role === "admin");
    updateCartCount();
  }

  function login(email, password) {
    email = email.trim().toLowerCase();
    const system = SYSTEM_ACCOUNTS.find((a) => a.email === email && a.password === password);
    if (system) {
      DB.set(KEYS.currentUser, { name: system.name, email: system.email, role: system.role });
      return { ok: true, role: system.role };
    }
    const users = DB.get(KEYS.users, []);
    const match = users.find((u) => u.email.toLowerCase() === email && u.password === password);
    if (match) {
      DB.set(KEYS.currentUser, { name: match.firstName + " " + match.lastName, email: match.email, role: "registered" });
      return { ok: true, role: "registered" };
    }
    return { ok: false };
  }

  function logout() {
    localStorage.removeItem(KEYS.currentUser);
    renderAuthUI();
    location.hash = "#home";
  }
  const logoutBtn = document.getElementById("navLogout");
  if (logoutBtn) logoutBtn.addEventListener("click", logout);

  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = document.getElementById("loginEmail").value;
      const password = document.getElementById("loginPassword").value;
      const msg = document.getElementById("loginMessage");
      const result = login(email, password);
      if (result.ok) {
        msg.textContent = "Login successful. Redirecting…";
        msg.className = "form-message ok";
        renderAuthUI();
        setTimeout(() => {
          location.hash = result.role === "admin" ? "#admin" : result.role === "staff" ? "#staff" : "#account";
        }, 400);
      } else {
        msg.textContent = "Incorrect email or password. Please try again, or contact us if you need help.";
        msg.className = "form-message error";
      }
    });
  }

  /* ---------------- Helpers ---------------- */
  function esc(str) {
    return String(str == null ? "" : str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  function startOfToday() { const d = new Date(); d.setHours(0, 0, 0, 0); return d; }
  function addDays(d, n) { const r = new Date(d); r.setDate(r.getDate() + n); return r; }
  function isBusinessDay(d) { const w = d.getDay(); return w !== 0 && w !== 6; }
  function nextBusinessDayOnOrAfter(d) { let r = new Date(d); while (!isBusinessDay(r)) r = addDays(r, 1); return r; }
  function addBusinessDays(d, n) { let r = new Date(d); while (n > 0) { r = addDays(r, 1); if (isBusinessDay(r)) n--; } return r; }
  function isoDate(d) { return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
  function parseIso(str) { const [y, m, d] = str.split("-").map(Number); return new Date(y, m - 1, d); }
  function prettyDate(d) { return DAYS[d.getDay()] + " " + d.getDate() + " " + MONTHS[d.getMonth()] + " " + d.getFullYear(); }
  function makeLabel(days) { return days <= 2 ? "2 days" : "1 week"; }

  /* ---------------- My Account ---------------- */
  function renderAccount() {
    const user = currentUser();
    if (!user) return;
    document.getElementById("accountName").textContent = "Welcome, " + user.name;
    document.getElementById("accountRole").textContent =
      "Role: " + user.role.charAt(0).toUpperCase() + user.role.slice(1);

    const orders = DB.get(KEYS.orders, []).filter((o) => o.email.toLowerCase() === user.email.toLowerCase());
    const ordersEl = document.getElementById("accountOrders");
    ordersEl.innerHTML = orders.length
      ? orders.slice().reverse().map((o) => `
        <div class="order-card">
          <p><b>Order ${esc(o.id)}</b> — R${o.total} <span class="badge ${badgeClass(o.status)}">${esc(o.status)}</span></p>
          <p class="muted">${o.items.map((i) => esc(i.name) + " × " + i.qty).join(", ")}</p>
          ${o.readyBy ? `<p class="muted">Ready by: ${prettyDate(parseIso(o.readyBy))}</p>` : ""}
          ${o.delivery ? `<p class="muted">${esc(o.delivery.courierName)} — ${prettyDate(parseIso(o.delivery.date))}, ${esc(o.delivery.slot)}<br>${o.delivery.method === "collect" ? "Collect at the Work Centre, Stellenbosch" : esc(o.delivery.address) + ", " + esc(o.delivery.city) + ", " + esc(o.delivery.province)}</p>` : ""}
          ${o.payment ? `<p class="muted"><b>Payment:</b> Bank transfer · ${esc(o.payment.reference)} · ${esc(o.payment.status.replace("_", " "))}</p>` : ""}
        </div>`).join("")
      : '<p class="muted">No orders yet.</p>';
  }

  function badgeClass(status) {
    if (["approved", "processing", "confirmed", "ready", "dispatched", "delivered", "collected"].includes(status)) return "ok";
    if (status === "rejected") return "rejected";
    return "";
  }

  /* ---------------- Delivery data (courier services + locations) ----------------
     Fees and transit times are placeholders — set the real ones here. */
  const LOCAL_TOWNS = ["Stellenbosch", "Franschhoek", "Paarl", "Somerset West", "Cape Town"];
  const LOCATIONS = {
    "Western Cape": ["Stellenbosch", "Franschhoek", "Paarl", "Somerset West", "Cape Town", "George"],
    "Gauteng": ["Johannesburg", "Pretoria"],
    "KwaZulu-Natal": ["Durban", "Pietermaritzburg"],
    "Eastern Cape": ["Gqeberha", "East London"],
    "Free State": ["Bloemfontein"]
  };
  function zoneFor(province, city) {
    if (LOCAL_TOWNS.includes(city)) return "local";
    if (province === "Western Cape") return "regional";
    return "national";
  }
  const COURIERS = [
    { id: "collect", name: "Collect from the Work Centre", note: "Free · Stellenbosch", zones: ["local", "regional", "national"], fee: { local: 0, regional: 0, national: 0 }, transit: { local: 0, regional: 0, national: 0 }, needsAddress: false, slots: ["09:00 – 12:00", "12:00 – 16:00"] },
    { id: "local", name: "SWC Local Delivery", note: "Our own vans · Stellenbosch, Winelands & Cape Town", zones: ["local"], fee: { local: 60 }, transit: { local: 1 }, needsAddress: true, slots: ["Morning (08:00 – 12:00)", "Afternoon (12:00 – 17:00)"] },
    { id: "standard", name: "Standard Courier", note: "Nationwide", zones: ["local", "regional", "national"], fee: { local: 80, regional: 110, national: 140 }, transit: { local: 2, regional: 3, national: 4 }, needsAddress: true, slots: ["Business hours (08:00 – 17:00)"] },
    { id: "express", name: "Express Courier", note: "Nationwide · fastest", zones: ["local", "regional", "national"], fee: { local: 120, regional: 160, national: 220 }, transit: { local: 1, regional: 1, national: 2 }, needsAddress: true, slots: ["Morning (before 12:00)", "Afternoon (12:00 – 17:00)"] }
  ];

  const el = (id) => document.getElementById(id);
  const sel = { courierId: null };

  /* ---------------- Shop cart ---------------- */
  function updateCartCount() {
    const cart = DB.get(KEYS.cart, []);
    const count = cart.reduce((n, i) => n + i.qty, 0);
    const badge = document.getElementById("cartCount");
    if (badge) badge.textContent = count;
  }

  document.querySelectorAll("button.cart[data-add]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const name = btn.dataset.add;
      const price = Number(btn.dataset.price || 0);
      const make = Number(btn.dataset.make || 2);
      const cart = DB.get(KEYS.cart, []);
      const existing = cart.find((i) => i.name === name);
      if (existing) existing.qty += 1;
      else cart.push({ name, price, qty: 1, make });
      DB.set(KEYS.cart, cart);
      updateCartCount();
      btn.textContent = "✓";
      setTimeout(() => (btn.textContent = "+"), 700);
    });
  });

  function cartSubtotal(cart) { return cart.reduce((sum, i) => sum + i.price * i.qty, 0); }
  function longestMake(cart) { return cart.reduce((m, i) => Math.max(m, i.make || 2), 0); }
  function readyDate(cart) { return addDays(startOfToday(), longestMake(cart)); }

  function currentCourier() { return COURIERS.find((c) => c.id === sel.courierId) || null; }
  function currentZone() {
    const p = el("delProvince").value, c = el("delCity").value;
    return p && c ? zoneFor(p, c) : null;
  }
  function deliveryFee() {
    const c = currentCourier(), z = currentZone();
    return c && z ? c.fee[z] : null;
  }

  function fillSelect(select, options, placeholder, keep) {
    const prev = keep ? select.value : "";
    select.innerHTML = `<option value="">${placeholder}</option>` +
      options.map((o) => `<option value="${esc(o.value)}">${esc(o.label)}</option>`).join("");
    if (prev && options.some((o) => o.value === prev)) select.value = prev;
  }

  function initDeliveryForm() {
    fillSelect(el("delProvince"), Object.keys(LOCATIONS).map((p) => ({ value: p, label: p })), "Select province…");
    el("delCity").innerHTML = '<option value="">Select province first</option>';
    el("delProvince").addEventListener("change", () => {
      const cities = LOCATIONS[el("delProvince").value] || [];
      fillSelect(el("delCity"), cities.map((c) => ({ value: c, label: c })), "Select town / city…");
      el("delCity").disabled = !cities.length;
      sel.courierId = null;
      refreshDelivery();
    });
    el("delCity").addEventListener("change", () => { sel.courierId = null; refreshDelivery(); });
    el("delDate").addEventListener("change", updateTotals);
    el("delSlot").addEventListener("change", updateTotals);
  }

  function refreshDelivery() {
    const cart = DB.get(KEYS.cart, []);
    const zone = currentZone();
    const group = el("courierGroup"), box = el("courierOptions");

    if (!zone) {
      group.disabled = true;
      box.innerHTML = '<p class="muted">Select your location to see available couriers.</p>';
    } else {
      const available = COURIERS.filter((c) => c.zones.includes(zone));
      if (!available.some((c) => c.id === sel.courierId)) sel.courierId = null;
      group.disabled = false;
      box.innerHTML = available.map((c) => {
        const fee = c.fee[zone];
        const transit = c.transit[zone];
        const speed = transit === 0 ? "Ready when your order is" : transit + " business day" + (transit > 1 ? "s" : "") + " after dispatch";
        return `<label class="courier ${sel.courierId === c.id ? "selected" : ""}">
          <input type="radio" name="courier" value="${c.id}" ${sel.courierId === c.id ? "checked" : ""}>
          <span class="courier-main"><b>${esc(c.name)}</b><small>${esc(c.note)} · ${speed}</small></span>
          <span class="courier-fee">${fee === 0 ? "Free" : "R" + fee}</span>
        </label>`;
      }).join("");
      box.querySelectorAll("input[name=courier]").forEach((r) => r.addEventListener("change", () => { sel.courierId = r.value; refreshDelivery(); }));
    }

    const courier = currentCourier();
    el("addressFields").hidden = !(courier && courier.needsAddress);

    // Date + slot options depend on make time + courier transit
    const dateSel = el("delDate"), slotSel = el("delSlot");
    if (courier && zone && cart.length) {
      const dispatch = nextBusinessDayOnOrAfter(readyDate(cart));
      const earliest = addBusinessDays(dispatch, courier.transit[zone]);
      const dates = [];
      let d = new Date(earliest);
      while (dates.length < 10) { if (isBusinessDay(d)) dates.push(new Date(d)); d = addDays(d, 1); }
      fillSelect(dateSel, dates.map((x) => ({ value: isoDate(x), label: prettyDate(x) })), "Select a date…", true);
      fillSelect(slotSel, courier.slots.map((s) => ({ value: s, label: s })), "Select a time slot…", true);
      if (courier.slots.length === 1) slotSel.value = courier.slots[0];
      dateSel.disabled = false; slotSel.disabled = false;
      el("delHint").textContent = "Earliest " + (courier.id === "collect" ? "collection" : "delivery") + ": " + prettyDate(earliest) + ". Weekdays only; public holidays may add a day.";
    } else {
      fillSelect(dateSel, [], "Choose a courier first");
      fillSelect(slotSel, [], "Choose a courier first");
      dateSel.disabled = true; slotSel.disabled = true;
      el("delHint").textContent = "Earliest dates already include the time needed to make your items.";
    }
    updateTotals();
  }

  function updateTotals() {
    const cart = DB.get(KEYS.cart, []);
    const sub = cartSubtotal(cart);
    const fee = deliveryFee();
    el("cartSubtotal").textContent = "R" + sub;
    el("cartDelivery").textContent = fee === null ? "—" : fee === 0 ? "Free" : "R" + fee;
    el("cartTotal").textContent = "R" + (sub + (fee || 0));
  }

  function renderCart() {
    const cart = DB.get(KEYS.cart, []);
    const itemsEl = el("cartItems");
    const form = el("deliveryForm");
    const summary = el("makeSummary");

    if (!cart.length) {
      itemsEl.innerHTML = '<p class="muted">Your cart is empty. Visit the <a href="#shop" data-route="shop">Shop</a> to add items.</p>';
      form.hidden = true; summary.hidden = true;
      el("paymentForm").hidden = true;
      el("cartTotals").hidden = true; el("checkoutBtn").hidden = true;
      return;
    }
    form.hidden = false; summary.hidden = false;
    el("paymentForm").hidden = false;
    el("cartTotals").hidden = false; el("checkoutBtn").hidden = false;
    renderBankDetails();

    itemsEl.innerHTML = cart.map((item, i) => `
      <div class="cart-item" data-index="${i}">
        <span class="name">${esc(item.name)}<small class="make-time">⏱ Made to order · ready in ${makeLabel(item.make || 2)}</small></span>
        <div class="qty">
          <button type="button" class="qty-dec" aria-label="Decrease quantity">−</button>
          <span>${item.qty}</span>
          <button type="button" class="qty-inc" aria-label="Increase quantity">+</button>
        </div>
        <span class="price">R${item.price * item.qty}</span>
        <button type="button" class="remove">Remove</button>
      </div>`).join("");

    summary.innerHTML = `<b>Your order will be ready by ${prettyDate(readyDate(cart))}</b><br><small>Longest item takes ${makeLabel(longestMake(cart))} to make. Everything is sent together once complete.</small>`;

    const changed = () => { DB.set(KEYS.cart, cart); updateCartCount(); renderCart(); };
    itemsEl.querySelectorAll(".cart-item").forEach((row) => {
      const idx = Number(row.dataset.index);
      row.querySelector(".qty-inc").addEventListener("click", () => { cart[idx].qty++; changed(); });
      row.querySelector(".qty-dec").addEventListener("click", () => { cart[idx].qty--; if (cart[idx].qty <= 0) cart.splice(idx, 1); changed(); });
      row.querySelector(".remove").addEventListener("click", () => { cart.splice(idx, 1); changed(); });
    });
    refreshDelivery();
  }

  function renderBankDetails() {
    const values = {
      checkoutBankName: BANK_DETAILS.bankName,
      checkoutAccountName: BANK_DETAILS.accountName,
      checkoutAccountNumber: BANK_DETAILS.accountNumber,
      checkoutBranchCode: BANK_DETAILS.branchCode
    };
    Object.entries(values).forEach(([id, value]) => {
      const node = el(id);
      if (node) node.textContent = value;
    });
    const ref = el("checkoutReference");
    const user = currentUser();
    if (ref) ref.textContent = user ? "SWC-" + user.email.split("@")[0].toUpperCase() : "SWC-ORDER";
  }

  const checkoutBtn = el("checkoutBtn");
  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", () => {
      const user = currentUser();
      const cart = DB.get(KEYS.cart, []);
      const msg = el("cartMessage");
      const fail = (t) => { msg.textContent = t; msg.className = "form-message error"; };
      if (!user) { location.hash = "#login"; return; }
      if (!cart.length) return fail("Your cart is empty.");

      const courier = currentCourier();
      const province = el("delProvince").value, city = el("delCity").value;
      if (!province || !city) return fail("Please select your delivery location.");
      if (!courier) return fail("Please choose a courier service.");
      const address = el("delAddress").value.trim(), phone = el("delPhone").value.trim();
      if (courier.needsAddress && (address.length < 5 || phone.length < 7)) return fail("Please enter a street address and a contact number for the courier.");
      const date = el("delDate").value, slot = el("delSlot").value;
      if (!date || !slot) return fail("Please choose a delivery date and time slot.");

      const payerName = el("payerName").value.trim();
      const payerBank = el("payerBank").value.trim();
      const paymentReference = el("paymentReference").value.trim();
      const paymentConfirmed = el("paymentConfirmed").checked;
      if (!payerName || payerName.length < 2) return fail("Please enter the account holder name used for the payment.");
      if (!payerBank) return fail("Please enter the bank you used for the payment.");
      if (!paymentReference || paymentReference.length < 3) return fail("Please enter your payment reference.");
      if (!paymentConfirmed) return fail("Please confirm that you have made the bank transfer.");

      const fee = deliveryFee();
      const subtotal = cartSubtotal(cart);
      const orders = DB.get(KEYS.orders, []);
      orders.push({
        id: "ORD-" + Date.now(), email: user.email, customer: user.name,
        items: cart, subtotal, total: subtotal + fee, status: "processing",
        date: isoDate(new Date()), readyBy: isoDate(readyDate(cart)),
        delivery: { method: courier.id, courierName: courier.name, province, city, address: courier.needsAddress ? address : "", phone, date, slot, fee },
        payment: { method: "bank_transfer", payerName, payerBank, reference: paymentReference, status: "awaiting_verification" }
      });
      DB.set(KEYS.orders, orders);
      DB.set(KEYS.cart, []);
      updateCartCount();
      el("delAddress").value = ""; el("delPhone").value = "";
      el("payerName").value = "";
      el("payerBank").value = "";
      el("paymentReference").value = "";
      el("paymentConfirmed").checked = false;
      sel.courierId = null;

      msg.textContent = "Order confirmed! Ready by " + prettyDate(readyDate(cart)) + ". Track it under My Account.";
      msg.className = "form-message ok";
      setTimeout(() => { location.hash = "#account"; }, 1400);
    });
  }
  initDeliveryForm();

  document.querySelectorAll(".staff-anchor").forEach((a) => {
    a.addEventListener("click", () => {
      setTimeout(() => {
        const target = document.getElementById(a.dataset.target);
        if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 50);
    });
  });

  /* ---------------- Staff dashboard ---------------- */
  const NEXT_STATUS = { processing: "ready", ready: "dispatched", dispatched: "delivered" };
  function nextStatusFor(o) {
    if (o.status === "ready" && o.delivery && o.delivery.method === "collect") return "collected";
    return NEXT_STATUS[o.status] || null;
  }

  function renderStaff() {
    const orders = DB.get(KEYS.orders, []);
    const open = orders.filter((o) => !["delivered", "collected"].includes(o.status));

    el("staffStats").innerHTML = `
      <div class="stat"><small>Open Orders</small><b>${open.length}</b></div>
      <div class="stat"><small>Ready to Send</small><b>${orders.filter((o) => o.status === "ready").length}</b></div>
      <div class="stat"><small>Total Orders</small><b>${orders.length}</b></div>`;

    const box = el("staffOrders");
    box.innerHTML = orders.length
      ? `<table class="table"><thead><tr><th>Order</th><th>Items &amp; make time</th><th>Delivery</th><th>Status</th></tr></thead><tbody>` +
        orders.slice().reverse().map((o) => {
          const next = nextStatusFor(o);
          const d = o.delivery;
          return `<tr data-id="${esc(o.id)}">
            <td><b>${esc(o.id)}</b><br><small class="muted">${esc(o.customer || o.email)}</small></td>
            <td>${o.items.map((i) => esc(i.name) + " × " + i.qty + " <small class=\"muted\">(" + makeLabel(i.make || 2) + ")</small>").join("<br>")}<br><small>Ready by ${prettyDate(parseIso(o.readyBy))}</small></td>
            <td>${d ? esc(d.courierName) + "<br>" + prettyDate(parseIso(d.date)) + ", " + esc(d.slot) + "<br><small class=\"muted\">" + (d.method === "collect" ? "Collect at centre" : esc(d.address) + ", " + esc(d.city) + " · " + esc(d.phone)) + "</small>" : "—"}</td>
            <td><span class="badge ${badgeClass(o.status)}">${esc(o.status)}</span>${next ? `<br><button type="button" class="btn green advance-btn" data-next="${next}">Mark ${next}</button>` : ""}</td>
          </tr>`;
        }).join("") + "</tbody></table>"
      : '<p class="muted">No orders yet.</p>';

    box.querySelectorAll(".advance-btn").forEach((b) => b.addEventListener("click", () => {
      const id = b.closest("tr").dataset.id;
      const all = DB.get(KEYS.orders, []);
      const order = all.find((o) => o.id === id);
      if (order) { order.status = b.dataset.next; DB.set(KEYS.orders, all); }
      renderStaff();
    }));

    const feedback = DB.get(KEYS.feedback, []);
    el("staffFeedback").innerHTML = feedback.length
      ? feedback.map((f) => `<p><b>${esc(f.name)}</b>: ${esc(f.message)}</p>`).join("")
      : '<p class="muted">No feedback submitted yet.</p>';
  }

  /* ---------------- Contact form ---------------- */
  const contactForm = document.getElementById("contactForm");
  if (contactForm) {
    contactForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const msg = document.getElementById("contactMessageStatus");
      msg.textContent = "Thanks for reaching out — we'll respond within one business day.";
      msg.className = "form-message ok";
      contactForm.reset();
    });
  }

  /* ---------------- Donation form ---------------- */
  const amountChoices = document.getElementById("amountChoices");
  const purposeChoices = document.getElementById("purposeChoices");
  const donationTotal = document.getElementById("donationTotal");
  let donationAmount = 100;
  function updateDonationTotal() {
    const monthly = document.getElementById("monthlyDonation").checked;
    donationTotal.textContent = "R" + donationAmount + (monthly ? " / month" : "");
  }
  if (amountChoices) {
    amountChoices.addEventListener("click", (e) => {
      if (!e.target.matches(".choice")) return;
      amountChoices.querySelectorAll(".choice").forEach((c) => c.classList.remove("active"));
      e.target.classList.add("active");
      donationAmount = Number(e.target.dataset.amount);
      updateDonationTotal();
    });
  }
  if (purposeChoices) {
    purposeChoices.addEventListener("click", (e) => {
      if (!e.target.matches(".choice")) return;
      purposeChoices.querySelectorAll(".choice").forEach((c) => c.classList.remove("active"));
      e.target.classList.add("active");
    });
  }
  const monthlyBox = document.getElementById("monthlyDonation");
  if (monthlyBox) monthlyBox.addEventListener("change", updateDonationTotal);

  const donationForm = document.getElementById("donationForm");
  if (donationForm) {
    donationForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const msg = document.getElementById("donationMessage");
      msg.textContent = "Thank you! Your generosity makes a real difference.";
      msg.className = "form-message ok";
    });
  }

  /* ---------------- AI chatbot (canned Q&A demo) ---------------- */
  const chatForm = document.getElementById("chatForm");
  const chatMessages = document.getElementById("chatMessages");
  const chatInput = document.getElementById("chatInput");

  const ANSWERS = [
    { k: ["deliver", "courier", "shipping", "collect", "how long", "make time"], a: "Every shop item is made to order: baskets and wall art take about 2 days, rugs and ceramics about 1 week. At checkout choose your town, a courier (or collect from us) and a delivery date and time slot — dates already allow for making time." },
    { k: ["program", "training", "service"], a: "We offer Folding, Sorting, Packaging and Photocopying services, plus several training programs. See the Services page for details." },
    { k: ["donate", "donation"], a: "You can donate any amount, one-off or monthly, on the Donate page. Every contribution supports training and independence." },
    { k: ["shop", "product", "buy"], a: "Our Shop has handmade products from our artisans. Items are made to order (2 days or 1 week). Add them to your cart, log in, then pick your courier and delivery time at checkout." },
    { k: ["contact", "phone", "email", "address"], a: "You can reach us on +27 21 555 0100, at info@stellenboschwork.org, or via the Contact page form." },
    { k: ["login", "log in", "password"], a: "Use the Login page with the email and password the Work Centre gave you. Need help? Contact us and we'll assist." }
  ];
  function botReply(text) {
    const lower = text.toLowerCase();
    const hit = ANSWERS.find((entry) => entry.k.some((word) => lower.includes(word)));
    return hit ? hit.a : "Thanks for your question! For anything specific, our team can help via the Contact page.";
  }
  function addMessage(text, who) {
    const div = document.createElement("div");
    div.className = "chat-message " + who;
    div.innerHTML = `<div class="bubble">${text}</div>`;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }
  if (chatForm) {
    chatForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const text = chatInput.value.trim();
      if (!text) return;
      addMessage(text, "user");
      chatInput.value = "";
      setTimeout(() => addMessage(botReply(text), "bot"), 400);
    });
    document.querySelectorAll(".quick button[data-question]").forEach((btn) => {
      btn.addEventListener("click", () => {
        addMessage(btn.dataset.question, "user");
        setTimeout(() => addMessage(botReply(btn.dataset.question), "bot"), 400);
      });
    });
  }

  /* ---------------- Video pop-up ---------------- */
  const videoModal = el("videoModal");
  const modalVideo = el("modalVideoPlayer");
  const homeVideo = el("homeVideoPlayer");
  let lastFocus = null;

  function openVideo() {
    if (!videoModal || !videoModal.hidden) return;
    lastFocus = document.activeElement;
    if (homeVideo) homeVideo.pause();
    videoModal.hidden = false;
    document.body.classList.add("modal-open");
    const closeBtn = videoModal.querySelector(".modal-close");
    if (closeBtn) closeBtn.focus();
  }
  function closeVideo() {
    if (!videoModal || videoModal.hidden) return;
    modalVideo.pause();
    videoModal.hidden = true;
    document.body.classList.remove("modal-open");
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  document.querySelectorAll("[data-open-video]").forEach((b) => b.addEventListener("click", openVideo));
  document.querySelectorAll("[data-close-video]").forEach((b) => b.addEventListener("click", closeVideo));
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeVideo(); });

  function maybeAutoPopup() {
    const onHome = (location.hash || "#home") === "#home";
    let seen = false;
    try { seen = sessionStorage.getItem("swc_videoSeen") === "1"; } catch (e) {}
    if (!onHome || seen) return;
    try { sessionStorage.setItem("swc_videoSeen", "1"); } catch (e) {}
    setTimeout(() => { if ((location.hash || "#home") === "#home") openVideo(); }, 1200);
  }

  /* ---------------- Init ---------------- */
  renderAuthUI();
  route();
  maybeAutoPopup();
})();
